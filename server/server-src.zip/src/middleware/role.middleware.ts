import type { NextFunction, Request, Response } from "express";

export const requireRole = (...roles: string[]) => {
    return (req: Request, res: Response, next: NextFunction) => {
        const user = req.user;

        if (!user) {
            return res.status(401).json({ error: "Authentication required" });
        }

        if (!roles.includes(user.role)) {
            return res.status(403).json({ error: "Forbidden" });
        }

        return next();
    };
};
